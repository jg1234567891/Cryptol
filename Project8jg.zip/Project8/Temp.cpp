#include "Temp.h"
temp::temp() {}
temp::temp(int temperature)
{
    temp::temperature = temperature;
}
void temp::setTemp(int temperature)
{
    temp::temperature = temperature;
}
int temp::getTemp()
{
    return temperature;
}
void temp::displayTemp()
{
    cout << "Temperature F: " << temperature << "\n";
}