#ifndef WIND_H
#define WIND_H
# include <iostream>

using namespace std;
class wind {
private:
    double speed;
    string direction;
public:
    wind();
    wind(double, string);
    void setWindsp(double);
    void setWinddr(string);
    double getWindsp();
    string getWinddr();
    void displayWind();
};

#endif
