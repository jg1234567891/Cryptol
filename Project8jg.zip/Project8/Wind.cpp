# include "wind.h"
wind::wind() {}
wind::wind(double speed, string direction)
{
    wind::speed = speed;
    wind::direction = direction;
}
void wind::setWinddr(string direction)
{
    wind::direction = direction;
}
void wind::setWindsp(double speed)
{
    wind::speed = speed;
}
double wind::getWindsp()
{
    return speed;
}
string wind::getWinddr()
{
    return direction;
}
void wind::displayWind()
{
    cout << "Wind Speed: " << speed << "mph" << " | " << "Wind Direction: " << direction << endl;
}