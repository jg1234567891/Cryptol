#ifndef WEATHER_H
#define WEATHER_H
#include<iostream>
#include "Wind.h"
#include "Temp.h"

using namespace std;
class weather {
private:
    wind windch;
    temp temperature;
public:
    weather();
 
    weather(double speed, string direction, int temperature);
    void setWWind(double speed, string direction);
    void setWTemp(int temperature);
    wind getWWind();
    temp getWTemp();
    void printWeather();
};
#endif
