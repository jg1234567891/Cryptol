#include "weather.h"
weather::weather() {}
weather::weather(double speed, string direction, int temp)
{
    windch.setWindsp(speed);
    windch.setWinddr(direction);
    temperature.setTemp(temp);
}
void weather::setWTemp(int temperature)
{
    weather::temperature.setTemp(temperature);
}
void weather::setWWind(double speed, string direction)
{
    windch.setWinddr(direction);
    windch.setWindsp(speed);
}
wind weather::getWWind()
{
    return windch;
}
temp weather::getWTemp()

{
    return temperature;
}
void weather::printWeather()

{
    temperature.displayTemp();
    windch.displayWind();
    cout << "\n";
}