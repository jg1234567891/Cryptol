// Project5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <cmath>
#include<iomanip>

using namespace std;


void printdata(double temp, double windsp, string name, string winddr) {

    if (name.empty()) {
        cout << "++++YOU HAVE NOT INPUT DATA++++\n";

    }
    else {
        cout << "Weather Station Name:" << name << endl;
        cout << "Temperature F:" << temp << "F" << endl;
        cout << "Wind Speed:" << windsp << "mph" << " " << " | Wind Direction: " << winddr << endl;
    }
}


void dubLeft(double x[], int length) {
    for (int i = 0; i < 1; i++) {
        double temp = x[0];
        for (int j = 0; j < length - 1; j++) {
            x[j] = x[j + 1];
        }
        x[length - 1] = temp;
    }
}

void sLeft(string x[], int length) {
    for (int i = 0; i < 1; i++) {
        string ddr = x[0];
        for (int j = 0; j < length - 1; j++) {
            x[j] = x[j + 1];
        }
        x[length - 1] = ddr;
    }
}





void indata(double& temp, double& windsp, string& name, string& winddr) {
    

    cout << "Hello what's your station name? " << endl;
    getline(cin, name);
    getline(cin, name);
    while (name.empty()) {
        cout << "Error thats not a name, please enter a name: \n";
        cin.clear();
        cin.ignore();
        getline(cin,name);
    }
    cout << "Great name, what is the temp F? " << endl;
    cin >> temp;
    while (!cin) {
        cout << "Error thats not a #, please enter a number value for temperature: \n";
        cin.clear();
        cin.ignore();
        cin >> temp;  
    }
    cout << "What is the wind speed? " << endl;
    cin >> windsp;
    while (!cin) {
        cout << "Error thats not a #, please enter a number value for wind speed: \n";
        cin.clear();
        cin.ignore();
        cin >> windsp;
    }
    cout << "Lastly what is the winds direction and sub direction if so ? " << endl;
    getline(cin, winddr);
    getline(cin, winddr);
    while (winddr.empty()) {
        cout << "Error thats not a wind direction, please enter one: \n";
        cin.clear();
        cin.ignore();
        getline(cin, winddr);
    }

}

int main()
{
    //john guseman
    //project 5 adjustment of project 2 & 3
    double temp = 0;
    double windsp = 0;
    string name;
    string winddr;
    const int size = 5;


    double tt[size];
    string na[size];
    double sp[size];
    string ddr[size];
    int count = 0;
    int choice;
    bool display = true;
    while (display != false) {
        cout << "*******************************\n";
        cout << " 1 - Start the data entry.\n";
        cout << " 2 - Print.\n";
        cout << " 3 - Print History.\n";
        cout << " 4 - Exit.\n";
        cout << " Enter what you would like to do: \n";
        cout << "*******************************\n";
        cin >> choice;
        
        switch (choice)
        {
        case 1:
            
            indata(temp, windsp, name, winddr);
            count++;
            if (count == 1) {
                ddr[0] = winddr;
                tt[0] = temp;
                sp[0] = windsp;
                na[0] = name;
            }
            if (count == 2) {
                ddr[1] = winddr;
                tt[1] = temp;
                sp[1] = windsp;
                na[1] = name;
            }
            if (count == 3) {
                ddr[2] = winddr;
                tt[2] = temp;
                sp[2] = windsp;
                na[2] = name;
            }
            if (count == 4) {
                ddr[3] = winddr;
                tt[3] = temp;
                sp[3] = windsp;
                na[3] = name;
            }
            if (count == 5) {
                ddr[4] = winddr;
                tt[4] = temp;
                sp[4] = windsp;
                na[4] = name;
            }
            if (count > 5) {
                dubLeft(tt, size);
                dubLeft(sp, size);
                sLeft(ddr, size);
                sLeft(na, size);
                na[4] = name;
                sp[4] = windsp;
                ddr[4] = winddr;
                tt[4] = temp;
            }
            break;

        case 2:
            printdata(temp, windsp, name, winddr);
            break;
        case 3:

            if (name.empty()) {
                cout << "++++YOU HAVE NOT INPUT DATA++++\n";
            }
            else {
                if (count > 5) {
                    count = 5;
               }
                for (int k = count - 1; k >= 0; k--) {
                 
                    cout << "********"<<"History of weather from entry: "<< k+1 << "********\n";
                    cout << "Weather Station Name:" << na[k] << endl;
                    cout << "Temperature F:" << tt[k] << "F" << endl;
                    cout << "Wind Speed:" << sp[k] << "mph" << " " << " | Wind Direction: " << ddr[k] << endl;
                }
            }
            break;
        case 4:
            cout << "You ended the program.\n";
            display = false;
            break;
        default:
            cout << "Not a Valid Command. \n";
            cout << "Enter any value to bring up menu.\n";
            cin >> choice;
            break;
        }

    }
    return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
