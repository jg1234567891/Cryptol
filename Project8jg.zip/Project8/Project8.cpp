
#include <iostream>
#include <string>
#include <cmath>
#include<iomanip>
#include "weather.h"


using namespace std;

string Display(string name)

{
    string choice, temp;
    do
    {
        cout << "************************************************\n";
        cout << " 1 - Start the data entry.\n";
        cout << " 2 - Print Last.\n";
        cout << " 3 - Print History.\n";
        cout << " 4 - Exit.\n";
        cout << " Enter what you would like to do: \n";
        cout << "************************************************\n";
        cout << "Enter number depending on what you want to do: " << endl;
        cin >> choice;
        temp = choice;
        for (int i = 0; i < choice.length(); ++i)
            temp[i] = (choice[i]);
        choice = temp;
    } while (!(choice == "1" || choice == "2" || choice == "3" || choice == "4"));
    return choice;
}

double getWindSp()

{
    double windsp;
    cout << "What is the wind speed? " << endl;
    cin >> windsp;
    while (!cin) {
        cout << "Error thats not a #, please enter a number value for wind speed: \n";
        cin.clear();
        cin.ignore();
        cin >> windsp;
    }
    return windsp;
}

string getWindDirection()

{
    string winddr;
    cout << "What is the winds direction and sub direction if so ? " << endl;
    getline(cin, winddr);
    getline(cin, winddr);
    while (winddr.empty()) {
        cout << "Error thats not a wind direction, please enter one: \n";
        cin.clear();
        cin.ignore();
        getline(cin, winddr);
    }
    return winddr;
}

int getTemperature()

{
    double temp;
    cout << "Thank you for the wind wind information, what is the temp F? " << endl;
    cin >> temp;
    while (!cin) {
        cout << "Error thats not a #, please enter a number value for temperature: \n";
        cin.clear();
        cin.ignore();
        cin >> temp;
    }
    return temp;
}


void sLeft(weather x[], int length) {
    for (int i = 0; i < 1; i++) {
        weather temp = x[0];
        for (int j = 0; j < length - 1; j++) {
            x[j] = x[j + 1];
        }
        x[length - 1] = temp;
    }
}

int main()
{
    //john guseman project 8 complete update
    weather* history;
    int historySize;
    string name, choice;
    int Count = 0;
    cout << "Hello, what is the name of the Weather Station: ";
    getline(cin, name);
    do {
        cout << "How many histories would you like to save? :";
        cin >> historySize;
        if (historySize <= 0)
            cout << "You must enter a postive number of stations to save" << "\n";

    } while (historySize <= 0);

    history = new weather[historySize];

    while (1)

    {


        choice = Display(name);

        if (choice == "1")

        {

            if (Count < historySize) {

                double speed = getWindSp();
                string direction = getWindDirection();
                int temp = getTemperature();
                history[Count].setWTemp(temp);
                history[Count].setWWind(speed, direction);
                Count++;

            }
            else {

                sLeft(history, historySize);
                double speed = getWindSp();
                string direction = getWindDirection();
                int temp = getTemperature();
                history[Count - 1].setWTemp(temp);
                history[Count - 1].setWWind(speed, direction);
            }
        }
        else if (choice == "2")

        {
            cout << "*************" << name << "*************" << endl;

            if (Count > 0) {

                history[Count - 1].printWeather();

            }

            else {

                cout << "++++YOU HAVE NOT INPUT DATA++++ \n";

            }

        }
        else if (choice == "3")

        {

            cout << "*************" << name << "*************" << endl;

            if (Count == 0)

                cout << "++++YOU HAVE NOT INPUT DATA++++ \n";

            int max = Count;

            for (int k = max - 1; k > -1; k--) {
                cout << "********" << "History of weather from entry: " << k + 1 << "********\n";
                cout << "\n";
                history[k].printWeather();

            }

        }
        else if (choice == "4")

        {

            break;

        }

    }

    return 0;

}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
