#ifndef TEMPERATURE_H
#define TEMPERATURE_H
#include <iostream>

using namespace std;
class temp {
private:
    int temperature;
public:
    temp();
    temp(int);
    void setTemp(int);
    int getTemp();
    void displayTemp();
};
#endif 
